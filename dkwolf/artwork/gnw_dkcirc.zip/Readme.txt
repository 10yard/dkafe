Disclaimer: I'm fine if you print this fan art for personal use, but I don't agree to it being sold in any form.

Credits:
Design, layout and editing by Lee Robson (hydef)
Background scans by Henrik Algestam